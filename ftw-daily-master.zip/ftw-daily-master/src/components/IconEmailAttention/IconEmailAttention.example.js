import IconEmailAttention from './IconEmailAttention';

export const Icon = {
  component: IconEmailAttention,
  props: {},
  group: 'icons',
};
