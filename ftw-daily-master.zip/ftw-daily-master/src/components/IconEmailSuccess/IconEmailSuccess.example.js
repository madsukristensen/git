import IconEmailSuccess from './IconEmailSuccess';

export const Icon = {
  component: IconEmailSuccess,
  props: {},
  group: 'icons',
};
