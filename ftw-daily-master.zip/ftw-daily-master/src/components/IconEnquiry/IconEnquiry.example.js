import IconEnquiry from './IconEnquiry';

export const Icon = {
  component: IconEnquiry,
  props: {},
  group: 'icons',
};
