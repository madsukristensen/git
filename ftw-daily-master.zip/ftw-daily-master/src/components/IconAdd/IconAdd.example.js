import IconAdd from './IconAdd';

export const Icon = {
  component: IconAdd,
  props: {},
  group: 'icons',
};
