# Testing Flex Template for Web

Documentation moved to the Flex Docs site:

https://www.sharetribe.com/docs/guides/how-to-test-ftw/
